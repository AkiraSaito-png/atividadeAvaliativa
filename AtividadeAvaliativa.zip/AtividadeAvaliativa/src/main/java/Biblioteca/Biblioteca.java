/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Biblioteca;

/**
 *
 * @author akira
 */
public abstract class Biblioteca {
    protected int id;

    public Biblioteca() {
    }

    public Biblioteca(int id) {
        this.id = id;
    }
    
    public abstract int getId();

    @Override
    public String toString() {
        return "ID: " + getId() + "\n";
    }
    
    
    
}
