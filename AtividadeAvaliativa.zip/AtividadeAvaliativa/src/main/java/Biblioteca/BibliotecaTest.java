/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Biblioteca;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author akira
 */
public class BibliotecaTest {
    public static void main(String[] args) {
        List<Usuario> usuarios = new ArrayList<>();     
        List<Livros> livros = new ArrayList<>();
        List<Emprestimo> emprestimos = new ArrayList<>();
        
        //lista de informações do usuario
        //                       |nome|         |E-Mail|            |senha|  |ID|
        usuarios.add(new Usuario("Akira", "akirassan@hotmail.com", "123456", 157));
        usuarios.add(new Usuario("Jose", "Jose@hotmail.com", "987654", 187));
        
        //lista de informações do catalofgo de livros
        //
        livros.add(new Livros("Declínio de um Homem", "Osamu Dazai", "primeira ediçao", "Chikuma Shobō", "Japão", 1948, 1));
        livros.add(new Livros("O Ladrão de Raios", "Rick Riordan", "primeira ediçao", "Miramax Books", "EUA", 2005, 2));
        livros.add(new Livros("O Hobbit", "J. R. R. Tolkien", "primeira ediçao", "George Allen & Unwin", "Reino Unido", 1937, 3));
        
        //lista de emprestimos / devoluçoes
        emprestimos.add(new Emprestimo(157, 1, LocalDate.EPOCH, LocalDate.EPOCH, true, 0));
        emprestimos.add(new Emprestimo(187, 3, LocalDate.EPOCH, LocalDate.EPOCH, true, 0));
        emprestimos.add(new Emprestimo(187, 2, LocalDate.MIN, LocalDate.EPOCH, false, 0));
       
        //menu
        String op = JOptionPane.showInputDialog("1- login\n2-listar usuarios\n3-buscar livro pelo id\n4- listar todos os livros");
        if(op.contains("1")){
            
           //capturar dados
           String verLogin = JOptionPane.showInputDialog("Insira o E-mail");
           String verSenha = JOptionPane.showInputDialog("Insira a senha");
           
           //verificar se o login e a senha estao corretos
           for(Usuario f : usuarios){
            if(f.getEmail().contains(verLogin) && f.getSenha().contains(verSenha)){
                System.out.println(":D");
                
                //emprestimos
                 int verEmp = Integer.parseInt(JOptionPane.showInputDialog("1- livros nao entregues\n2- livros entregues"));
                 if(verEmp == 1){
                     for(Emprestimo r : emprestimos){
                         if(r.isDevolvido() == false && r.getIdUsuario() == f.id){
                             JOptionPane.showMessageDialog(null, "livro(s) nao entregue\ncod.: " + r.getIdLivro());
                         }
                     }
                 }
                 else if(verEmp == 2){
                     for(Emprestimo r : emprestimos){
                         if(r.isDevolvido() == true && r.getIdUsuario() == f.id){
                             JOptionPane.showMessageDialog(null, "livro(s) entregue\ncod.: " + r.getIdLivro());
                         }
                     }
                 }
                 else{
                     JOptionPane.showMessageDialog(null, "comando invalido!!");
                 }
            }
            else{
                JOptionPane.showMessageDialog(null, "O E-mail informado nao existe!!");
            }
           }         
        }
        //exibir todos os usuarios e IDs
        
        else if(op.contains("2")){
            for(Usuario f : usuarios){
                JOptionPane.showMessageDialog(null, f.getNome() + " : " + f.getId());
            }
        }
        //buscar livros
        else if(op.contains("3")){
            int verLivro = Integer.parseInt(JOptionPane.showInputDialog("Insira codigo do livro"));
            for(Livros g : livros){
                if(verLivro == g.getId()){
                    System.out.println(":D");
                    JOptionPane.showMessageDialog(null, g.getTitulo() +
                            "\n" + 
                            g.getAutor() +
                            "\n" + 
                            g.getEditora() +
                            "\n" + 
                            g.getEdicao() +
                            "\n" + 
                            g.getCidade() +
                            "\n" + 
                            g.getAnopublicacao());
                }
                else{
                    JOptionPane.showMessageDialog(null, "codigo do livro não existe");
                }
            }
        }
        else if(op.contains("4")){
            for(Livros g : livros){
                JOptionPane.showMessageDialog(null, g.toString());
            }
        }
        else{
            JOptionPane.showMessageDialog(null, "comando invalido");
        }
        
        
        
            
    }
}
